package com.cognizant;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.annotation.ComponentScan;
/**
 * 
 * @author PRACHI MISHRA
 * Main class to run the application
 * annotated with @EnableDiscoveryClient to be registered as client
 */
@SpringBootApplication
@ComponentScan(basePackages = "com.*")
@EnableDiscoveryClient
public class AdminServiceMovieApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdminServiceMovieApplication.class, args);
	}

}
