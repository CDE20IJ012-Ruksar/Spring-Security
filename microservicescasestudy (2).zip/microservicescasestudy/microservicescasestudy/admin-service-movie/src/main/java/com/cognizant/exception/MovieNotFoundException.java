package com.cognizant.exception;
/**
 * 
 * @author PRACHI MISHRA
 * Exception class for Movie Not Found
 */
public class MovieNotFoundException extends Exception {
	/**
	 * default and parameterized constructor
	 */
	public MovieNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	private static final long serialVersionUID = 1L;

	public MovieNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
