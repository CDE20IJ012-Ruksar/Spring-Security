package com.cognizant.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.cognizant.exception.MenuItemNotFoundException;
import com.cognizant.model.Cart;
import com.cognizant.model.MenuItem;
import com.cognizant.service.CartService;
import com.cognizant.service.MenuItemService;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @author PRACHI MISHRA
 * Cart controller to check the mappings of jsp pages 
 * annotated with @RestController
 *
 */
@RestController
@Slf4j
@RequestMapping("customer")
public class CartController {

	/**
	 * cartService reference of CartService autowired 
	 */
	@Autowired
	private CartService cartService;
	/**
	 * menuItemService reference of MenuItemService autowired 
	 */
	@Autowired
	private MenuItemService menuItemService;

	/**
	 * loads the customer menu item list and adds the list to attribute "menuitemCustomerList"
	 * by invoking menuItemService.getCustomerMenuItems()
	 * 
	 * @return List of menu items for customer
	 
	 */
	
	/*
	 * Method -get
	 * http://localhost:8083/customer-service-truyum/customer/show-menu-list-customer
	 */
	
	@GetMapping(value="/show-menu-list-customer",produces="application/json")
	public List<MenuItem> showMenuItemListCustomer(){
		log.info("Start");
		List<MenuItem>menuitemCustomerList=menuItemService.getCustomerMenuItems();
		log.debug("Customer Menu Items: {}",menuitemCustomerList);
		log.info("End");
		return menuitemCustomerList;
	}
	
	
	/**
	 * adds the item in cart of user
	 * by invoking cartService.addToCart
	 * 
	 * @param menuitemId to be added in cart
	 * @return String - menu item added to cart
	 * @throws MenuItemNotFoundException 
	 */
	/*
	 * Method -post
	 * http://localhost:8083/customer-service-truyum/customer/add-to-cart/3
	 */
	@PostMapping("/add-to-cart/{menuItemId}")
	public String addToCart(@PathVariable("menuItemId") int menuItemId) throws MenuItemNotFoundException {
		log.info("Start ");
		List<MenuItem> menuItemList = menuItemService.getCustomerMenuItems();
		//map.put("menuItemList", menuItemList);
		log.debug("List:{}", menuItemList);
		cartService.addToCart(menuItemId);
		log.info("End ");
		return "Menu Item added to cart";
	}
	/**
	 * shows the item in cart of user
	 * by invoking cartService.getCart()
	 * 
	 * @return Cart of user 1
	 */
	/*
	 * Method -get
	 * http://localhost:8083/customer-service-truyum/customer/show-cart
	 */
	@GetMapping("/show-cart")
	public List<Cart> cart() throws Exception {
		log.info("Start");
		List<Cart> carts = cartService.getCart();
		log.debug("Cart:{}", carts);

		log.info("End");
		return carts;
	}
	/**
	 * deletes the item from cart of user
	 * by invoking cartService.deleteById()
	 * 
	 * @param userid and menuid to delete menuitem of required id 
	 * @return String - menu item deleted from cart
	 */
	/*
	 * Method -delete
	 * http://localhost:8083/customer-service-truyum/customer/remove-cart/3/1
	 */
	@DeleteMapping("/remove-cart/{menuItemId}/{userId}")
	public String deleteItem(@PathVariable("menuItemId") int menuId,@PathVariable("userId") int userId) throws Exception{
		log.info("Start");
		cartService.deleteItem(menuId, userId);
		List<Cart> carts = cartService.getCart();
		log.debug("Cart:{}", carts);
		log.info("End");
		if(carts.size()==0) {
			return "No Items in cart";
		}
		else {
			return "Menu Item deleted from cart";
		}
		
	}
}