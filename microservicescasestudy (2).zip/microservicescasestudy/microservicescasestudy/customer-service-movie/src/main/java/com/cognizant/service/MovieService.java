package com.cognizant.service;

import java.util.List;

import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cognizant.model.Movie;
import com.cognizant.repository.MovieRepository;

import lombok.extern.slf4j.Slf4j;
/**
 * 
 * @author PRACHI MISHRA
 *Service class to implement movie repository
 *
 */
@Service
@Slf4j
public class MovieService {
	
	/**
	 * movieRepository reference of MovieRepository is autowired in this class
	 */
	@Autowired
	MovieRepository movieRepository;
	
	/**
	 *
	 * @return list of movies for customer where ative=yes and dateoflaunch<=curdate
	 */
	@Transactional
	public List<Movie> getMovieListCustomer() {
		log.info("Start ");
		return movieRepository.findAllCustomer();
	}

	/**
	 *
	 * @param id for which movie to be fetched
	 */
	@Transactional
	public Movie getMovie(int id) {
		log.info("Start ");
		return movieRepository.getOne(id);
	}

}
