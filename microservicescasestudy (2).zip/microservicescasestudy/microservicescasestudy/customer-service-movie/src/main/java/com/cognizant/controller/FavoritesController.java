package com.cognizant.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.model.Favorites;
import com.cognizant.model.Movie;
import com.cognizant.service.FavoritesService;
import com.cognizant.service.MovieService;
import com.cognizant.exception.MovieNotFoundException;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @author PRACHI MISHRA
 * Favorites controller to check the mappings of methods
 * annotated with @RestController
 * Slf4j to log data 
 */
@RestController
@Slf4j
@RequestMapping("customer")
public class FavoritesController {
	
	/**
	 * favoritesService reference of FavoritesService autowired 
	 */
	@Autowired
	private FavoritesService favoritesService;
	/**
	 * movieService reference of MovieService autowired 
	 */
	@Autowired
	private MovieService movieService;
	
	/**
	 * loads customer menu items list and adds the attribute "menuItemListCustomer"
	 * by invoking movieService.getMovieListCustomer()
	 *
	 * @return movie list of customer
	 */
	/*
	 * Method -get
	 * http://localhost:8085/customer-service-movie/customer/show-movie-list-customer
	 */
	@GetMapping(value="/show-movie-list-customer",produces="application/json")
	public List<Movie> showMovieCustomer() {
		log.info("Start");
		List<Movie> movieCustomerList = movieService.getMovieListCustomer();
		log.debug("Customer Movie List: {}", movieCustomerList);
		log.info("End");
		return movieCustomerList;
	}
	

	/**
	 * adds the movie in favorites of customer
	 * by invoking favoritesService.addToFavorites
	 * 
	 * @param movieId to be added
	 * @return String
	 */
	/*
	 * Method -post
	 * http://localhost:8085/customer-service-movie/customer/add-to-favorites/2
	 * {
    	"id":2,
    	"users":2
		}
	 */
	@PostMapping("/add-to-favorites/{movieId}")
	public String addToFavorites(@PathVariable("movieId") int movieId)throws MovieNotFoundException {
		log.info("Start ");
		List<Movie> movieList = movieService.getMovieListCustomer();
		log.debug("List:{}", movieList);
		favoritesService.addToFavorites(movieId);
		log.info("End ");
		return "Movie added to favorites successfully";
	}

	/**
	 * shows the movie in favorites of user
	 * by invoking favoritesService.getFavorites()
	 * 
	 * @return list of favorites 
	 */
	/*
	 * Method -get
	 * http://localhost:8085/customer-service-movie/customer/favorites
	 */
	@GetMapping("/favorites")
	public List<Favorites> favorites() throws MovieNotFoundException {
		log.info("Start");
		List<Favorites> favorites = favoritesService.getFavorites();
		int total = favorites.size();
		log.debug("Total Movies in Favorites:{}", total);
		log.info("End");
		return favorites;
	}

	/**
	 * deletes the movie from favorites of customer
	 * by invoking favoritesService.deleteFav()
	 * 
	 * @param favId to delete movie with that id
	 * @return String that movie details deleted successfully
	 */
	/*
	 * Method -delete
	 * http://localhost:8085/customer-service-movie/customer/remove-favorite/1
	 */
	@DeleteMapping("/remove-favorite/{favId}")
	public String deleteItem(@PathVariable("favId") int favId) throws MovieNotFoundException {
		log.info("Start");
		favoritesService.deleteFav(favId);
		List<Favorites> favoritess = favoritesService.getFavorites();
		log.debug("Favorites:{}", favoritess);
		if (favoritess.size() == 0)
			return "No Movies in favorites";
		log.info("End");
		return "Movie removed from favorites successfully";
	}

}
