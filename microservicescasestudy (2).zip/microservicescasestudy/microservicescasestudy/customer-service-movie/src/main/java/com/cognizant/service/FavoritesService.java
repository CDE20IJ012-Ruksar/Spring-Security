package com.cognizant.service;

import java.util.List;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cognizant.exception.MovieNotFoundException;
import com.cognizant.model.Favorites;
import com.cognizant.model.Movie;
import com.cognizant.model.Users;
import com.cognizant.repository.FavoritesRepository;
import lombok.extern.slf4j.Slf4j;
/**
 * 
 * @author PRACHI MISHRA
 *Service class to implement favorites repository
 *
 */
@Service
@Slf4j
public class FavoritesService {
	
	/**
	 * favoritesRepository reference of FavoritesRepository is autowired in this class
	 */
	@Autowired
	FavoritesRepository favoritesRepository;
	/**
	 * movieService reference of MovieService is autowired in this class
	 */
	@Autowired
	MovieService movieService;
	/**
	 * userService reference of UserService is autowired in this class
	 */
	@Autowired
	UserService userService; 
	
	/**
	 *
	 * @param movieId that has to be added to favorites
	 */
	@Transactional
	public void addToFavorites(int movieId) throws MovieNotFoundException{
		log.info("Start ");
		Users users = userService.getUser(1);
		Movie movie = movieService.getMovie(movieId);
		Favorites favorites = new Favorites();
		favorites.setUsers(users);
		favorites.setMovie(movie);
		log.debug("Favorites:{}", favorites);
		favoritesRepository.save(favorites);
		log.info("End ");
	}

	/**
	 *
	 * @return list of movie details for customer
	 */
	@Transactional
	public List<Favorites> getFavorites(){
		log.info("Start ");
		return favoritesRepository.findById(1);
	}
	/**
	 *
	 * @param movieid that to be removed from favorites
	 */
	@Transactional
	public void deleteFav(int id) {
		log.info("Start ");
		favoritesRepository.delete(favoritesRepository.getOne(id));
	}
	
	
}
