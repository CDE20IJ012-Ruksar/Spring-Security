package com.cognizant.exception;
/**
 * 
 * @author PRACHI MISHRA
 * Exception class for menu item not found
 */
public class MenuItemNotFoundException extends Exception{

	/**
	 * default and parametarized constructor
	 */
	private static final long serialVersionUID = 1L;

	public MenuItemNotFoundException() {
		super();
	}

	public MenuItemNotFoundException(String message) {
		super(message);
		
	}

	
}
