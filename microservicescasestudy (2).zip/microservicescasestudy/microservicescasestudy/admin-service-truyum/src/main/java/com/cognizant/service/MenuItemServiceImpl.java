package com.cognizant.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cognizant.exception.MenuItemNotFoundException;
import com.cognizant.model.MenuItem;
import com.cognizant.repository.MenuItemRepository;
import lombok.extern.slf4j.Slf4j;
/**
 * 
 * @author PRACHI MISHRA
 *Service class to implement menuitem repository
 *
 */
@Service
@Slf4j
public class MenuItemServiceImpl implements MenuItemService {
	/**
	 * menuItemkRepository reference of MenuItemRepository is autowired in this class
	 */
	@Autowired
	private MenuItemRepository menuItemRepository;
	/**
	 *
	 * @return list of menu items for admin
	 */
	@Override
	public List<MenuItem> getAdminMenuItems() {
		log.info("Start");
		List<MenuItem> menuItemList= menuItemRepository.findAll();
		log.debug("Admin Menu Item List: {}",menuItemList);
		log.info("End");
		return menuItemList;
	}
	/**
	 *@param id for which menuitem to be found
	 * @return menu item for given id
	 */
	@Transactional
	@Override
	public MenuItem getMenuItem(int id) throws MenuItemNotFoundException{
		
		log.info("Start");
		MenuItem menuItem= menuItemRepository.getOne(id);		
		log.debug("Get Menu Item: {}",menuItem);
		log.info("End");
		return menuItem;
	}
	/**
	 *
	 * @param menu item to be updated
	 */
	@Transactional
	@Override
	public String editMenuItem(MenuItem menuItem) throws MenuItemNotFoundException{
		log.info("Start");
		MenuItem item = menuItemRepository.getOne(menuItem.getId());
		item.setName(menuItem.getName());
		item.setPrice(menuItem.getPrice());
		item.setActive(menuItem.getActive());
		item.setDateOfLaunch(menuItem.getDateOfLaunch());
		item.setCategory(menuItem.getCategory());
		item.setFreeDelivery(menuItem.getFreeDelivery());
		menuItemRepository.save(item);
		log.info("End");
		return "MenuItem with the id "+menuItem.getId()+" updated successfully";
	}

}
