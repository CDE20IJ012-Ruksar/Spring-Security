package com.cognizant.controller;

import java.util.List;
import javax.transaction.SystemException;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.exception.MenuItemNotFoundException;
import com.cognizant.model.MenuItem;
import com.cognizant.service.MenuItemService;
import lombok.extern.slf4j.Slf4j;
/**
 * 
 * @author PRACHI MISHRA
 * MenuItem controller to check the mappings of functions
 * annotated with @RestController
 * Slf4j to maintain log
 */
@RestController
@Slf4j
@RequestMapping("admin")
public class MenuItemController {

	/**
	 * menuItemService reference of menuItemService is autowired
	 */
	@Autowired
	private MenuItemService menuItemService;
	
	/**
	 * loads the admin menu item list and adds the list to attribute "menuItemList"
	 * by invoking menuItemService.getMenuItemListAdmin()
	 * 
	 * @return List of menu items for admin
	 */
	
	/*
	 * Method -get
	 * http://localhost:8083/admin-service-truyum/admin/show-menu-list-admin
	 */
	
	@GetMapping(value="/show-menu-list-admin",produces="application/json")
	public List<MenuItem> showMenuItemListAdmin(){
		log.info("Start");
		List<MenuItem>menuitemAdminList=menuItemService.getAdminMenuItems();
		log.debug("Admin Menu Items: {}",menuitemAdminList);
		log.info("End");
		return menuitemAdminList;
	}
	
	/**
	 * loads showMenuItem when the user provides mapping as show-menu-item in url
	 * list adds attribute "menuItem" by invoking menuItemService.getMenuItem(id)
	 * 
	 * @param id of menu item 
	 * @return Menu Item to be edited
	 * @throws MenuItemNotFoundException 
	 */
	/*
	 * Method -get
	 * http://localhost:8083/admin-service-truyum/admin/show-menu-item/5
	 */
	@GetMapping(value="/show-menu-item/{menuItemId}")
	public MenuItem showMenuItem(@PathVariable("menuItemId") int id) throws MenuItemNotFoundException {
		log.info("Start");
		MenuItem menuItem=menuItemService.getMenuItem(id);
		log.debug("Menu Item: {}",menuItem);
		log.info("End");
		return menuItem;

	}
	
	/**
	 * applies the changes to menuItem checks if the given parameters are valid
	 * this methods edits menuItem by invoking
	 * menuItemService.editMenuItem(menuItem)
	 * 
	 * @param menuItem
	 * @return String Menu Item edited successfully 
	 */
	/*
	 * Method -put
	 * http://localhost:8083/admin-service-truyum/admin/edit-menu-item
        "id": 5,
        "name": "Brownie",
        "price": 150.0,
        "active": "Yes",
        "dateOfLaunch": "2022-11-02",
        "category": "Dessert",
        "freeDelivery": "Yes"
    }
	 */
	@PutMapping("/edit-menu-item")
	public String editMenuItem(@Valid @RequestBody MenuItem menuItem) {
		log.info("Start");
			try {
				menuItemService.editMenuItem(menuItem);
				log.info("End");
				return "Menu Item Edited successfully";
			} catch (MenuItemNotFoundException e) {
				return "Menu Item can't be updated";
			}
			
		
}
}
