package com.cognizant.model;

import java.sql.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author PRACHI MISHRA
 * entity class for movie
 * @Entity indicates Spring Data JPA that it is an entity class for the
 *         application
 * @Table helps in defining the mapping database table 
 * lombok used to generate getters and setters
 */
@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "movie")
@JsonIdentityInfo(generator=ObjectIdGenerators.PropertyGenerator.class,property = "id")
public class Movie {
	
	/**
	 * instance variables
	 * 
	 * @Id helps in defining the primary key
	 * @Column helps in defining the mapping table column
	 * 
	 */
	@Id
	@Column(name = "movie_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@Column(name = "movie_title")
	private String title;
	
	@Column(name = "movie_box_office")
	private String boxOffice;
	
	@Column(name = "movie_active")
	private String active;
	
	@Column(name = "movie_date_of_launch")
	private Date dateOfLaunch;
	
	@Column(name = "movie_genre")
	private String genre;
	
	@Column(name = "movie_has_teaser")
	private String hasTeaser;

	
}
