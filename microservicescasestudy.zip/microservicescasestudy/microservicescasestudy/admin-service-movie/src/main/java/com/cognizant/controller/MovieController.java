package com.cognizant.controller;

import java.util.List;

import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.model.Movie;
import com.cognizant.service.MovieService;
import com.cognizant.exception.MovieNotFoundException;

import lombok.extern.slf4j.Slf4j;
/**
 * 
 * @author PRACHI MISHRA
 * Movie controller to check the mappings of jsp pages 
 * annotated with @RestController
 * Slf4j to log data 
 */
@RestController
@Slf4j
@RequestMapping("admin")
public class MovieController {
	
	/**
	 * movieService is reference of MovieService is autowired
	 */
	@Autowired
	private MovieService movieService;

	/**
	 * loads the admin Movie list and adds the list to attribute movieList
	 * by invoking menuItemService.getMenuItemListAdmin()
	 * 
	 * @return movie list of admin
	 */
	/*
	 * Method -get
	 * http://localhost:8085/admin-service-movie/admin/show-movie-list-admin
	 */
	@GetMapping(value="/show-movie-list-admin",produces="application/json")
	public List<Movie> showMovieListAdmin() throws MovieNotFoundException {
		log.info("Start");
		List<Movie> movieAdminList = movieService.getMovieListAdmin();
		log.debug("Admin Movie List: {}", movieAdminList);
		log.info("End");
		return movieAdminList;
	}

	/**
	 * loads showMovie() when the admin gives url get mapping 
	 * list adds attribute "movie" by invoking movieService.getMovie(id)
	 * 
	 * @param id
	 * @return movie 
	 * @throws MovieNotFoundException 
	 */
	/*
	 * Method -get
	 * http://localhost:8085/admin-service-movie/admin/get-movie/5
	 */
	@GetMapping(value="/get-movie/{movieId}")
	public Movie showMovie(@PathVariable("movieId") int id) throws MovieNotFoundException {
		log.info("Start");
		Movie movie;
			movie = movieService.getMovie(id);
			log.debug("Movie to be edited: {}",movie);
			log.info("End");
			return movie;
		
	}

	/**
	 * applies the changes to movie checks if the given parameters are valid
	 * this methods edits movie by invoking
	 * movieService.editMovie(movie)
	 * 
	 * @param movie
	 * @return String Movie details edited successfully
	 * @throws MovieNotFoundException 
	 */
	
	/*
	 * Method -put
	 * http://localhost:8085/admin-service-movie/admin/edit-movie
	 *  {
        "id": 5,
        "title": "Life Of Pi",
        "boxOffice": "15000000",
        "active": "Yes",
        "dateOfLaunch": "2016-03-27",
        "genre": "Adventure",
        "hasTeaser": "Yes"
    }
	 */
	@PutMapping("/edit-movie")
	public String editMovie(@Valid @RequestBody Movie movie) throws MovieNotFoundException {
		log.info("Start");
		if(movie.getHasTeaser()==null)
				movie.setHasTeaser("No");
		movieService.editMovie(movie);
		log.info("End");
		return "Movie details edited successfully";
	}
}
