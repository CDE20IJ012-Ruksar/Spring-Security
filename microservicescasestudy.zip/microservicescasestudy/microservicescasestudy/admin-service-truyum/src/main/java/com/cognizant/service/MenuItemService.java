package com.cognizant.service;

import java.util.List;

import com.cognizant.exception.MenuItemNotFoundException;
import com.cognizant.model.MenuItem;
/**
 * 
 * @author PRACHI MISHRA
 *Service Interface to declare methods for menuItem
 *
 */
public interface MenuItemService {

	/**
	 * list of menuItem for admin
	 */
	public List<MenuItem> getAdminMenuItems();
	/**
	 * to get MenuItem on basis of required id
	 * @param id
	 * @return menuItem
	 */
	public MenuItem getMenuItem(int id) throws MenuItemNotFoundException;
	/**
	 * to editMenuItem 
	 * @param menuItem
	 * @return string
	 */
	public String editMenuItem(MenuItem menuItem) throws MenuItemNotFoundException;
}
