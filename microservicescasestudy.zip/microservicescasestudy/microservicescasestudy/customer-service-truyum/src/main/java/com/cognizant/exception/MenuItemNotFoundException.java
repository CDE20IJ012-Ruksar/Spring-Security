package com.cognizant.exception;
/**
 * 
 * @author PRACHI MISHRA
 * Exception class for menuItem not found
 */
public class MenuItemNotFoundException extends Exception {

	/**
	 * default and parametarized constructor
	 */
	private static final long serialVersionUID = 1L;

	public MenuItemNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MenuItemNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
