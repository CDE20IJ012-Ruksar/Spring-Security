package com.cognizant.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.exception.MenuItemNotFoundException;
import com.cognizant.model.MenuItem;
import com.cognizant.repository.MenuItemRepository;
import lombok.extern.slf4j.Slf4j;
/**
 * 
 * @author PRACHI MISHRA
 *Service class to implement menuitem repository
 *
 */
@Service
@Slf4j
public class MenuItemServiceImpl implements MenuItemService {
		/**
		 * menuItemkRepository reference of MenuItemRepository is autowired in this class
		 */
	@Autowired
	private MenuItemRepository menuItemRepository;
	/**
	 *@param id for which menuitem to be found
	 * @return menu item for given id
	 */
	@Transactional
	@Override
	public MenuItem getMenuItem(int id) throws MenuItemNotFoundException{
		
		log.info("Start");
		MenuItem menuItem= menuItemRepository.getOne(id);		
		log.debug("Get Menu Item: {}",menuItem);
		log.info("End");
		return menuItem;
	}
	/**
	 *
	 * @return list of menu items for customer where ative=yes and dateoflaunch<=curdate
	 */
	@Override
	public List<MenuItem> getCustomerMenuItems() {
		log.info("Start");
		List<MenuItem> menuItemList= menuItemRepository.getMenuItemListCustomer();
		log.debug("Customer Menu Item List: {}",menuItemList);
		log.info("End");
		return menuItemList;

	}


}
