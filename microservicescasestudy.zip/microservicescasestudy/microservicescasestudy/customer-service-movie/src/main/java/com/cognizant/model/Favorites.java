package com.cognizant.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author PRACHI MISHRA
 * entity class for favorites
 * @Entity indicates Spring Data JPA that it is an entity class for the
 *         application
 * @Table helps in defining the mapping database table 
 *
 */
@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "favorites")
@JsonIdentityInfo(generator=ObjectIdGenerators.PropertyGenerator.class,property = "id")
public class Favorites {
	/**
	 * instance variables
	 * 
	 * @Id helps in defining the primary key
	 * @Column helps in defining the mapping table column
	 * 
	 */
	@Id
	@Column(name = "favorite_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@ManyToOne
	@JoinColumn(name = "favorite_user_id")
	private User user;
	
	@ManyToOne
	@JoinColumn(name = "favorite_movie_id")
	private Movie movie;

}