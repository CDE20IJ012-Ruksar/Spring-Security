package com.cognizant.service;

import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cognizant.model.User;
import com.cognizant.repository.UserRepository;

import lombok.extern.slf4j.Slf4j;
/**
 * 
 * @author PRACHI MISHRA
 *Service class to implement user repository
 *
 */
@Service
@Slf4j
public class UserService{
	
	/**
	 * userRepository reference of USerRepository is autowired in this class
	 */
	@Autowired
	UserRepository userRepository;
	
	
	/**
	 * 
	 * @param userId to find user for given id
	 * @return user with that id
	 */
	@Transactional
	public User getUser(int userId) {
		log.info("Start");
		return userRepository.getOne(userId);
	}

}
