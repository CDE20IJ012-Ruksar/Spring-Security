package com.cognizant.truyum.adminservice.service;

import java.util.List;

import com.cognizant.truyum.adminservice.exception.MenuItemException;
import com.cognizant.truyum.adminservice.model.MenuItem;


/**
 * 
 * @author Geetanjali
 *
 */
public interface MenuItemService {
	
	/**
	 * 
	 * @return
	 */
	public List<MenuItem> getMenuItemListAdmin();
	
	/**
	 * 
	 * @param id
	 * @return
	 * @throws MenuItemException
	 */
	public MenuItem getMenuItem(int id) throws MenuItemException;
	/**
	 * 
	 * @param menuItem
	 * @return
	 * @throws MenuItemException
	 */
	public String editMenuItem(MenuItem menuItem) throws MenuItemException;
	

}
