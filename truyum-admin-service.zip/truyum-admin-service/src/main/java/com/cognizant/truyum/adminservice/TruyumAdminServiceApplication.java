package com.cognizant.truyum.adminservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TruyumAdminServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(TruyumAdminServiceApplication.class, args);
	}

}
