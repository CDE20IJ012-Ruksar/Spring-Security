package com.cognizant.truyum.adminservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cognizant.truyum.adminservice.model.MenuItem;




/**
 * 
 * @author Geetanjali
 *
 */
public interface MenuItemRepository extends JpaRepository<MenuItem, Integer>{

}
