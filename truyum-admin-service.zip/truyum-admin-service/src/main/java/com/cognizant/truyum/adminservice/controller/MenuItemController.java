package com.cognizant.truyum.adminservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.truyum.adminservice.exception.MenuItemException;
import com.cognizant.truyum.adminservice.model.MenuItem;
import com.cognizant.truyum.adminservice.service.MenuItemService;

import lombok.extern.slf4j.Slf4j;


/**
 * 
 * @author Geetanjali
 *
 */
@RestController
@Slf4j
public class MenuItemController {
	

	@Autowired
	private MenuItemService menuItemService;

	/**
	 * 
	 * @return
	 */
	
	@GetMapping(value = "/show-menu-list")
	public List<MenuItem> showMenuItemListAdmin() {
		log.info("Start");
		List<MenuItem> menuItemList = menuItemService.getMenuItemListAdmin();
		log.debug("Admin Menu List: {}", menuItemList);

		log.info("End");
		return menuItemList;
	}

	/**
	 * 
	 * @param id
	 * @return
	 * @throws MenuItemException
	 */
	
	@GetMapping(value = "/show-menu-item/{id}")
	public MenuItem showMenuItemById(@PathVariable int id) throws MenuItemException {
		log.info("Start");
		MenuItem menuItem = menuItemService.getMenuItem(id);
		log.debug("Found Menu Item: {}", menuItem);

		log.info("End");
		return menuItem;
	}
	/**
	 * 
	 * @param menuItem
	 * @return
	 * @throws MenuItemException
	 */
	
	@PutMapping(value = "/menu-item/update")
	public String editMenuItem(@RequestBody MenuItem menuItem) throws MenuItemException {
		log.info("Start");
		log.debug("status of edited menu item:"+menuItemService.editMenuItem(menuItem));
		log.info("end");
		return menuItemService.editMenuItem(menuItem);
	}

	

}
