package com.cognizant.truyum.adminservice.exception;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.cognizant.truyum.adminservice.model.CustomErrorResponse;




/**
 * 
 * @author Geetanjali
 *
 */
@RestControllerAdvice
public class GlobalExceptionHandler {

	/**
	 * 
	 * @param ex
	 * @return
	 */
	@ExceptionHandler({MenuItemException.class})
	public ResponseEntity<CustomErrorResponse> handleProductException(MenuItemException ex){
		CustomErrorResponse response=new CustomErrorResponse();
		response.setTimestamp(LocalDateTime.now());
		response.setStatus(HttpStatus.NOT_FOUND);
		response.setReason("Invalid MenuItem id Provided");
		response.setMessage(ex.getMessage());
		
		return new ResponseEntity<CustomErrorResponse>(response,HttpStatus.NOT_FOUND);
	}
	
	/**
	 * 
	 * @param ex
	 * @return
	 */
	
	
	
	/**
	 * 
	 * @param ex
	 * @return
	 */
	@ExceptionHandler({Exception.class})
	public ResponseEntity<CustomErrorResponse> handleException(Exception ex){
		CustomErrorResponse response=new CustomErrorResponse();
		response.setTimestamp(LocalDateTime.now());
		response.setStatus(HttpStatus.NOT_FOUND);
		response.setReason("Invalid information");
		response.setMessage(ex.getMessage());
		
		return new ResponseEntity<CustomErrorResponse>(response,HttpStatus.NOT_FOUND);
	}
}
