package com.cognizant.truyum.adminservice.exception;


/**
 * 
 * @author Geetanjali
 *
 */
public class MenuItemException extends Exception{

	/**
	 * 
	 * @param message
	 */
	public MenuItemException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
