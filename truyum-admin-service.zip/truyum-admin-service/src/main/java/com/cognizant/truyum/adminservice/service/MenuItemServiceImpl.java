package com.cognizant.truyum.adminservice.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.truyum.adminservice.exception.MenuItemException;
import com.cognizant.truyum.adminservice.model.MenuItem;
import com.cognizant.truyum.adminservice.repository.MenuItemRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class MenuItemServiceImpl implements MenuItemService {
	
	@Autowired
	private MenuItemRepository menuItemRepository;

	@Override
	public List<MenuItem> getMenuItemListAdmin() {
		// TODO Auto-generated method stub
		log.info("start");
		List<MenuItem> menuItemList = menuItemRepository.findAll();
		for(MenuItem item:menuItemList)
		{
			
		}
		log.debug("List Of Menu items found are {}",menuItemList);
		log.info("End");
		return menuItemList;
	}
	/**
	 * 
	 * @param id
	 * @return
	 * @throws MenuItemException
	 */

	@Override
	public MenuItem getMenuItem(int id) throws MenuItemException {
		// TODO Auto-generated method stub
		log.info("start");
		
			
			log.debug("Menu Item found :{}",menuItemRepository.findById(id).get());
			log.info("End");
			return menuItemRepository.findById(id)
					.orElseThrow(()->new MenuItemException("Menu item with id "+id+"does not exist"));
		
	}

	/**
	 * 
	 * @param menuItem
	 * @return
	 * @throws MenuItemException
	 */
	@Override
	public String editMenuItem(MenuItem menuItem) throws MenuItemException {
		// TODO Auto-generated method stub
		log.info("start");
		Optional<MenuItem> optional = menuItemRepository.findById(menuItem.getId());
		if(optional.isPresent())
		{
			MenuItem menuItemFound = optional.get();
			menuItemFound.setActive(menuItem.getActive());
			menuItemFound.setCategory(menuItem.getCategory());
			menuItemFound.setName(menuItem.getName());
			menuItemFound.setPrice(menuItem.getPrice());
			menuItemFound.setDateOfLaunch(menuItem.getDateOfLaunch());
			menuItemFound.setFreeDelivery(menuItem.getFreeDelivery());
			
			menuItemRepository.save(menuItemFound);
			log.debug("Updated menu item:"+menuItemFound);
			log.info("end");
			return "Successfully Updated";
		}
		else {
		
		throw new MenuItemException("Entered MenuItem is not present");
		}
	}

}
