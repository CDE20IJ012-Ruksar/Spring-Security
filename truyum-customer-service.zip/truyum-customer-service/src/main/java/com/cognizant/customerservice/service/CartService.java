package com.cognizant.customerservice.service;

import java.util.List;

import com.cognizant.customerservice.exception.MenuItemException;
import com.cognizant.customerservice.exception.UserException;



/**
 * 
 * @author Geetanjali
 *
 */
public interface CartService {
	/**
	 * 
	 * @param userId
	 * @param menuItemId
	 * @return
	 * @throws UserException
	 * @throws MenuItemException
	 */
	public String addCartItem(int userId,int menuItemId) throws UserException, MenuItemException;
	
	/**
	 * 
	 * @param userId
	 * @param menuItemId
	 * @return
	 * @throws UserException
	 */
	public String deleteCartItem(int userId,int menuItemId) throws UserException;
	/**
	 * 
	 * @param userId
	 * @return
	 * @throws UserException
	 */
	public List<Object> getAllCartItems(int userId) throws UserException;
	
	

}
