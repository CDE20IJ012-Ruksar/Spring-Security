package com.cognizant.customerservice.service;

import java.util.List;

import com.cognizant.customerservice.exception.MenuItemException;
import com.cognizant.customerservice.model.MenuItem;


/**
 * 
 * @author Geetanjali
 *
 */
public interface MenuItemService {
	
	/**
	 * 
	 * @return
	 */
	public List<MenuItem> getMenuItemListAdmin();
	
	/**
	 * 
	 * @param id
	 * @return
	 * @throws MenuItemException
	 */
	public MenuItem getMenuItem(int id) throws MenuItemException;
	/**
	 * 
	 * @param menuItem
	 * @return
	 * @throws MenuItemException
	 */
	public String editMenuItem(MenuItem menuItem) throws MenuItemException;
	

}
