package com.cognizant.customerservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.customerservice.exception.MenuItemException;
import com.cognizant.customerservice.exception.UserException;
import com.cognizant.customerservice.model.MenuItem;
import com.cognizant.customerservice.service.CartService;
import com.cognizant.customerservice.service.MenuItemService;

import lombok.extern.slf4j.Slf4j;

@RestController

@Slf4j
/**
 * 
 * @author Geetanjali
 *
 */
public class CartController {

	
	@Autowired
	private CartService cartService;
	
	@Autowired
	private MenuItemService menuItemService;
	
	@GetMapping(value = "/show-menu-list")
	public List<MenuItem> showMenuItemListAdmin() {
		log.info("Start");
		List<MenuItem> menuItemList = menuItemService.getMenuItemListAdmin();
		log.debug("Admin Menu List: {}", menuItemList);

		log.info("End");
		return menuItemList;
	}
	/**
	 * 
	 * @param userId
	 * @param menuItemId
	 * @return 
	 * @throws UserException
	 * @throws MenuItemException
	 */
	
	@PostMapping(value="/addToCart/{userId}/{menuItemId}")
	public String addCartIem(@PathVariable int userId,@PathVariable int menuItemId) throws UserException, MenuItemException
	{
		log.info("start");
		log.debug("added menuitem in the cart");
		log.info("end");
		return cartService.addCartItem(userId, menuItemId);
		
	}
	
	/**
	 * 
	 * @param userId
	 * @return
	 * @throws UserException
	 */
	
	@GetMapping(value="/getCartItems/{userId}")
	public List<Object> getAllCartItems(@PathVariable int userId) throws UserException
	{
		log.info("start");
		log.debug("All cart items:"+cartService.getAllCartItems(userId));
		log.info("end");
		return cartService.getAllCartItems(userId);
	}
	
	/**
	 * 
	 * @param userId
	 * @param menuItemId
	 * @return
	 * @throws UserException
	 */
	
	@DeleteMapping(value="/deleteFromCart/{userId}/{menuItemId}")
	public String deleteCartItem(@PathVariable int userId, @PathVariable int menuItemId) throws UserException
	{
		log.info("start");
		log.debug("Successfully Deleted");
		log.info("end");
		return cartService.deleteCartItem(userId, menuItemId);
	}
	
}
