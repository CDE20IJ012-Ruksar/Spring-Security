package com.cognizant.customerservice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cognizant.customerservice.model.Cart;


/**
 * 
 * @author Geetanjali
 *
 */
public interface CartRepository extends JpaRepository<Cart, Integer>{

	/**
	 * 
	 * @param userId
	 * @return
	 */
	
	@Query(nativeQuery = true ,value=" select * from menu_item m where m.me_id IN (select ct_pr_id from cart where ct_us_id=:userId);")
	/*@Query(" select m from MenuItem m "
			+ "where m.id  IN"
			+"(select c.menuItem.id from Cart c"
			+ " where c.user.userId=?1)")*/
	//@Query("Select m from MenuItem m , Cart c where c.user.id=?1")
		
	//List<MenuItem> getAllCartItems(@Param("userId") Integer userId);
	List<Object> getAllCartItems(@Param("userId") Integer userId);
	
	
}
