package com.cognizant.customerservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cognizant.customerservice.model.User;


/**
 * 
 * @author Geetanjali
 *
 */
public interface UserRepository extends JpaRepository<User, Integer>{

}
