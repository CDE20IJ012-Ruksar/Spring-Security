package com.cognizant.customerservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TruyumCustomerServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(TruyumCustomerServiceApplication.class, args);
	}

}
