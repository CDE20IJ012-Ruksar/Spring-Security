package com.cognizant.customerservice.exception;

/**
 * 
 * @author Geetanjali
 *
 */
public class UserException extends Exception{

	/**
	 * 
	 * @param message
	 */
	public UserException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
