package com.cognizant.customerservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cognizant.customerservice.model.MenuItem;




/**
 * 
 * @author Geetanjali
 *
 */
public interface MenuItemRepository extends JpaRepository<MenuItem, Integer>{

}
