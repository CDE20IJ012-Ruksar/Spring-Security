package com.cognizant.customerservice.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.customerservice.exception.MenuItemException;
import com.cognizant.customerservice.exception.UserException;
import com.cognizant.customerservice.model.Cart;
import com.cognizant.customerservice.model.MenuItem;
import com.cognizant.customerservice.model.User;
import com.cognizant.customerservice.repository.CartRepository;
import com.cognizant.customerservice.repository.MenuItemRepository;
import com.cognizant.customerservice.repository.UserRepository;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @author Geetanjali
 *
 */
@Service
@Slf4j
public class CartServiceImpl implements CartService {

	@Autowired
	private CartRepository cartRepository;
	@Autowired
	private MenuItemRepository menuItemRepository;
	@Autowired
	private UserRepository userRepository;
	
	/**
	 * 
	 * @param userId
	 * @param menuItemId
	 * @return
	 * @throws UserException
	 * @throws MenuItemException
	 */
	
	@Override
	public String addCartItem(int userId, int menuItemId) throws UserException, MenuItemException {
		// TODO Auto-generated method stub
		log.info("start");
		menuItemRepository.findById(menuItemId).orElseThrow(()->new MenuItemException("Item with entered id "+menuItemId+"is not present"));
		Optional<MenuItem> foundItem = menuItemRepository.findById(menuItemId);
		userRepository.findById(userId).orElseThrow(()->new UserException("Entered user id:"+userId+" is not present"));
		Optional<User> foundUser = userRepository.findById(userId);
		//if(foundItem.isPresent() && foundUser.isPresent())
		//{
			User user = foundUser.get();
			MenuItem menuItem = foundItem.get();
			Cart cart=new Cart();
			cart.setUser(user);
			cart.setMenuItem(menuItem);
			cartRepository.save(cart);
			log.debug("Added cart Item:"+cart.getMenuItem()+"for user:"+cart.getUser());
			log.info("end");
			return "Item successfully added";
		//}
		//return null;
	}

	/**
	 * 
	 * @param userId
	 * @return
	 * @throws UserException
	 */

	@Override
	public List<Object> getAllCartItems(int userId) throws UserException {
		
		log.info("start");
		List<Cart> list = cartRepository.findAll();
		
		for(Cart cart:list)
		{
			if(cart.getUser().getUserId()==userId)
			{
				log.debug("List of menu items found for user "+userId+" are:"+cartRepository.getAllCartItems(userId));
				log.info("end");
				return cartRepository.getAllCartItems(userId);
			}
		}
		throw new UserException("Entered user id "+userId+" is not present");
		
		
	}

	/**
	 * 
	 * @param userId
	 * @param menuItemId
	 * @return
	 * @throws UserException
	 */
	@Override
	public String deleteCartItem(int userId, int menuItemId) throws UserException {
		// TODO Auto-generated method stub
		log.info("start");
		List<Cart> cartList = cartRepository.findAll();
		
		for(Cart cart:cartList)
		{
			if(cart.getMenuItem().getId()==menuItemId && cart.getUser().getUserId()==userId)
			{
				log.debug("The item deleted from the cart is :"+cart.getMenuItem().getId());
				log.info("end");
				cartRepository.delete(cart);
				return "Item Successfully Deleted";
			}
		}
		throw new UserException("There is no menu item with id "+menuItemId+" for user with id "+userId);
		
	}

}
